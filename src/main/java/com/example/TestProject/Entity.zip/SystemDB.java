package com.example.TestProject.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "SYSTEM_DB")
public class SystemDB {
    @Id
    @Column(name = "SYSTEM_ID")
    private String systemId;

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, name = "SYSTEM_NUM")
    private int systemNum;

    @Column(name = "SYSTEM_NAME")
    private String systemName;

    @Column(name = "SYSTEM_DESC")
    private String systemDesc;

    @Column(name = "SYSTEM_CATEGORY")
    private String systemCategory;

    @Column(name = "SYSTEM_TYPE")
    private String systemType;

    @Column(name = "IP_ADDR")
    private String ipAddr;

    @Column(name = "SYSTEM_GROUP")
    private String systemGroup;

    @Column(name = "C_DT")
    private LocalDateTime systemDt;

    @Column(name = "C_BY")
    private String systemBy;

    @Column(name = "U_DT")
    private LocalDateTime updateDt;

    @Column(name = "U_BY")
    private String updateBy;

}
