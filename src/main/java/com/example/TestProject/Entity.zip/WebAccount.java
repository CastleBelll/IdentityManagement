package com.example.TestProject.Entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "WEB_ACCOUNT")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WebAccount {
    @Id
    @Column(name = "WEB_ID")
    String webId;

    @Column(name = "WEB_NAME")
    String webName;

    @Column(name = "WEB_QUALIFICATION")
    String webQualification;
}
