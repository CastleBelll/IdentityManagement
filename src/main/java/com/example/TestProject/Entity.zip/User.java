package com.example.TestProject.Entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Table(name = "member")  //맵핑할 db의 table 이름
@Entity(name = "member")
public class User {
    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "password")
    private String password;
}
