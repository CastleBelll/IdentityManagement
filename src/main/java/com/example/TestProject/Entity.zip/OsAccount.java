package com.example.TestProject.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "OS_ACCOUNT")
@NoArgsConstructor
@AllArgsConstructor
public class OsAccount {
    @Id
    @Column(name ="OS_ID")
    private String OsId;

    @ManyToOne
    @JoinColumn(name="WEB_ID")
    private WebAccount webAccount;

    @Column(name = "OS_CATEGORIES")
    private String osCategories;
}
