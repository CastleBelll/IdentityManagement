package com.example.TestProject.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "SERVICE_ACCOUNT")
@NoArgsConstructor
@AllArgsConstructor
public class ServiceAccount {
    @Id
    @Column(name ="AC_ID")
    private String accountId;

    @ManyToOne
    @JoinColumn(name="OS_ID")
    private OsAccount osAccount;

    @ManyToOne
    @JoinColumn(name="WEB_ID")
    private WebAccount webAccount;

    @Column(name = "OS_USER_ID", unique = true)
    private String osUserId;
}
