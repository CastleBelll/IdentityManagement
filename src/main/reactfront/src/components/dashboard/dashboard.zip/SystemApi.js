import axios from 'axios';



const accessToken = localStorage.getItem("accessToken");

export const SystemApi = axios.create({
    baseURL: 'http://localhost:8080/system', // 백엔드 API 엔드포인트
    headers: {
        'Authorization': `Bearer ${accessToken}`, // Authorization 헤더에 토큰을 추가
        'Content-Type': 'application/json', // 다른 헤더도 필요하다면 추가 가능
    },
});

// API 호출
export const getSystemList = async () => {
    try {
        const response = await SystemApi.get('/select');
        console.log('백엔드 응답:', response.data);
        return response.data;
    } catch (error) {
        console.error('에러 발생:', error);
        return []; // 에러 발생 시 빈 배열 반환
    }
};

